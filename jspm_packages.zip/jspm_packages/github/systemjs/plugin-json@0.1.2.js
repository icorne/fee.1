define(["github:systemjs/plugin-json@0.1.2/json"], function(main) {
  return main;
});