define(["npm:aurelia-path@1.0.0-beta.1.2.2/aurelia-path"], function(main) {
  return main;
});