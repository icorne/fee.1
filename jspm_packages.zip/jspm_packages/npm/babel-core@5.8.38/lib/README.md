## Diving into Babel

If you look around in the various directories in here you'll find some details
about the organization of the Babel codebase.
