/* */ 
"format cjs";
module.exports = require("./lib/api/register/node");
