define(["npm:aurelia-binding@1.0.0-beta.1.3.6/aurelia-binding"], function(main) {
  return main;
});