define(["npm:aurelia-route-recognizer@1.0.0-beta.1.2.1/aurelia-route-recognizer"], function(main) {
  return main;
});