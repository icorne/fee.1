node buffer tests that require ES6 (e.g. "for..of" construct)
