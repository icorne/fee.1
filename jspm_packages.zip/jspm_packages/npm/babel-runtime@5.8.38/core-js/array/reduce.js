/* */ 
module.exports = { "default": require("core-js/library/fn/array/reduce"), __esModule: true };