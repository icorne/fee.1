/* */ 
module.exports = { "default": require("core-js/library/fn/symbol"), __esModule: true };