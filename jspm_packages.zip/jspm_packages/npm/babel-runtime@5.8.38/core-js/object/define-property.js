/* */ 
module.exports = { "default": require("core-js/library/fn/object/define-property"), __esModule: true };