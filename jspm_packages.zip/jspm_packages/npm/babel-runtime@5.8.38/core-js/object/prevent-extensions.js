/* */ 
module.exports = { "default": require("core-js/library/fn/object/prevent-extensions"), __esModule: true };