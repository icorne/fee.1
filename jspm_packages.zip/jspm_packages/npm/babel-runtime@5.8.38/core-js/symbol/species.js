/* */ 
module.exports = { "default": require("core-js/library/fn/symbol/species"), __esModule: true };