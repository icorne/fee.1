/* */ 
module.exports = { "default": require("core-js/library/fn/reflect/define-property"), __esModule: true };