/* */ 
module.exports = { "default": require("core-js/library/fn/reflect/get-own-property-descriptor"), __esModule: true };