/* */ 
module.exports = require('./instanceof');
