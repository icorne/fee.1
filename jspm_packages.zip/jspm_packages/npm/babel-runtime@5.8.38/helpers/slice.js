/* */ 
"use strict";

exports["default"] = Array.prototype.slice;
exports.__esModule = true;